#include <string>
#include <fstream>
#include "DynamicArray.h"
#include <iostream>
#include <stdexcept>
#include <vector>
#include <stdlib.h> 

typedef float Element;






		//Default Constructor
		DynamicArray::DynamicArray(){
			dynamicArray=0;
			arraySize=0;
			arrayCapacity=0;
		}
		
		//Explicit Value Constructor
		DynamicArray::DynamicArray(int size, Element e){
			
			arraySize=0;
			
			
			if(size>=0){
			arrayCapacity=size;
			arraySize=size;
			dynamicArray=new Element[size];
			for(int i=0; i<size; i++){
				dynamicArray[i]=e;
				//arraySize=i+1;
			}}
			else{
			std::cout<<"Incorrect Size inputted"<<std::endl;
			exit(EXIT_FAILURE);
			
			}
		}
		
		//Destructor
		DynamicArray::~DynamicArray(){
		delete []dynamicArray;
		}

		//Add to end

		void DynamicArray::push_back(Element e){
			//double check to see if array size=capacity	
			//if size is at capacity increase capacity
			//if not add one to size and element
			//check to see if element e is not null?
		/*	arraySize++;
			//try{
			if(dynamicArray==NULL){
				arraySize=1;
				arrayCapacity=1;
				dynamicArray=new Element(arraySize);
				dynamicArray[0]=e;
				std::cout<<"array Size "<<arraySize;

	
			}
			else if(arraySize>=arrayCapacity){
			arrayCapacity=arrayCapacity*2;
			Element* temp=new Element[arrayCapacity];
			for(int i=0; i<arraySize-2; i++){
				temp[i]=dynamicArray[i];
			}
				
				temp[arraySize-1]=e;
			for(int i=arraySize; i<arrayCapacity;i++){
				temp[i]=0;
			}
				
				
				delete[]dynamicArray;
				dynamicArray=temp;
				

				
			}
		//if(e==NULL){
				int temp1;
				temp1=e;
			
			}
			else{

				
				dynamicArray[arraySize]=e;
				arraySize+=1;
			}
			
			//}
			//catch(std::out_of_range& oor){
			//	std::cerr<<"Out of range error"<<oor.what()<<'\n';
			//}
	
*/

/*		std::cout<<"array Size is:  "<<arraySize<<std::endl;
		
		
		arraySize++;
		int arrayIndex=arraySize-2;
		std::cout<<"array Index is:  "<<arrayIndex<<std::endl;
		if(dynamicArray==NULL){
			arrayCapacity=1;
			arraySize=1;
			dynamicArray= new Element[arrayCapacity];
			dynamicArray[0]=e;
		std::cout<<"array Index is:  "<<arraySize<<std::endl;
		}
		
		else if(arraySize>=arrayCapacity){
			arrayCapacity=arrayCapacity*2;
			Element* temp=new Element[arrayCapacity];
			for(int i=0; i<=arrayIndex; i++){
				temp[i]=dynamicArray[i];
				
			}
			arrayIndex++;
			std::cout<<"array Index is:  "<<arrayIndex<<std::endl;
			temp[arrayIndex]=e;
			for(int i=arraySize+2; i<arrayCapacity; i++){
				temp[i]=-1;
			}
			
			delete[] dynamicArray;
			dynamicArray=temp;
			
		}
		else{
			dynamicArray[arrayIndex]=e;
			std::cout<<"array Index is"<<arrayIndex<<std::endl;

		}
			
			
		
*/

		std::cout<<"array Size is:  "<<arraySize<<std::endl;
		
		
		arraySize++;
		if(dynamicArray==NULL){
			arrayCapacity=1;
		//	arraySize=1;
			dynamicArray= new Element[arrayCapacity];
			dynamicArray[0]=e;
		}
		
		else if(arraySize>=arrayCapacity){
			arrayCapacity=arrayCapacity*2;
			Element* temp=new Element[arrayCapacity];
			for(int i=0; i<arraySize; i++){
				std::cout<<"dynamic array at "<<i<<" is "<<dynamicArray[i]<<std::endl;
				temp[i]=dynamicArray[i];
				temp[arraySize-1]=e;				
			}
			for(int i=arraySize; i<arrayCapacity; i++){
				temp[i]=-1;
			}
			
			delete[] dynamicArray;
			dynamicArray=temp;
			
		}
		else{
			dynamicArray[arraySize-1]=e;

			}
		}
		//Remove from end and return
		Element DynamicArray::pop_back(){
			Element temp=-1;
			if(arraySize > 0 )
			{
			temp = dynamicArray[arraySize-1];
			arraySize--;
			 
			  
			  
			}
			
		
			return temp;

			
	}	
		//Search, return position in array, -1 if not found
		int DynamicArray::search(Element e){
			if(dynamicArray==NULL){
			
			return -1;
			}
			for(int i=0; i<arraySize; i++){
				std::cout<<"arrayDynamic["<<i<<"] is "<< dynamicArray[i]<<std::endl;
			}
			
		/*	for(int i=0; i<=arraySize+1; ++i){	

				std::cout<<"index i is "<<i<<std::endl;		
				std::cout<<"dynamicArray[i] is:"<<dynamicArray[i]<<std::endl;
				if(dynamicArray[i]==e){

					std::cout<<"index i is: "<<i<<std::endl;			
					return i+1;
					}
				
			}*/
			for(int i=0; i<arraySize; i++){
				
				std::cout<<"index i is "<<i<<std::endl;		
				std::cout<<"dynamicArray[i] is:"<<dynamicArray[i]<<std::endl;
			if(dynamicArray[i]==e){
				std::cout<<"index i is"<<i<<std::endl;
				return i;
				
			}
	}
			
				return -1;
			
			
				
			
		}


		//Indicate whether or not the provided index is valid
		bool DynamicArray::valid_index(int index){
			if(index<0){
				return false;
			}
			else if(index==NULL){
				return false;
			}
			else if(index>=arraySize){
				return false;
			}
			else{
				return true;
			}
		

		}

		//Return the size of the array (number of elements currently in the array)
		int DynamicArray::size(){
			return arraySize;
		}

		//Return the capacity of the array (number of elements the array can currently hold)
		int DynamicArray::capacity(){
			return arrayCapacity;
		}
	
		void DynamicArray::push_at(Element e, int i){
			Element* temp= new Element;
			if(i>=arraySize && i>=0){
				for(int j=0; j<i; j++)
				{
				temp[j]=dynamicArray[j];	
				}
				temp[i]=e;
				
				for(int k=i+1; k<arraySize+1; k++)
				{
				temp[k]=dynamicArray[k];
				}
			}



		}

