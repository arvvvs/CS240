#include <iostream>
#include <fstream>
#include <cstring>
#include "preLab09.h"
#include <string>
using namespace std;
int main(){
/*BST BST1;
cout<<"post order"<<endl;
BST1.post_order();
cout<<"insert 1"<<endl;
BST1.insert(1);
cout<<"post order again"<<endl;
BST1.post_order();
cout<<"insert 12190218"<<endl;
BST1.insert(12190218);
cout<<"insert number 2398423"<<endl;
BST1.insert(2398423);
cout<<"pre order"<<endl;
BST1.pre_order();
cout<<"insert number 32435"<<endl;
BST1.insert(32435);
cout<<"insert five"<<endl;
BST1.insert(5);
cout<<"in order"<<endl;
BST1.in_order();
BST1.pre_order();
cout<<"search for five inserted"<<endl;
BST1.search(5);
cout<<"search for four uninserted"<<endl;
BST1.search(4);
cout<<"preorder search"<<endl;
BST1.pre_order();
cout<<"remove 5"<<endl;
BST1.remove(5);
cout<<"remove root"<<endl;
BST1.remove(1);
cout<<"insert 7"<<endl;
BST1.insert(7);
cout<<"in order"<<endl;
BST1.in_order();
BST1.post_order();
*/
BST BST2;
/*BST2.insert(1);
BST2.insert(2);
BST2.insert(3);
BST2.insert(4);
BST2.isBalanced();
cout<<BST2.isBalanced()<<endl;
cout<<endl;
BST2.pre_order();
cout<<endl;
BST2.in_order();
cout<<endl;
BST2.remove(1);
BST2.remove(4);
BST2.remove(3);
BST2.remove(3);
cout<<endl;
BST2.in_order();
cout<<endl;
*/
BST2.read("BSTtry");
BST2.pre_order();
cout<<endl;
BST2.in_order();
BST2.write("output.txt");
bool life;
life=BST2.symmetry();
if(life==true){
  cout<<"true"<<endl;
}
else{
  cout<<"false"<<endl;
}}
